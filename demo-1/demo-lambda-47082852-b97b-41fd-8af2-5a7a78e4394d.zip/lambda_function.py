import json
import logging
import boto3
from botocore.exceptions import ClientError

s3_client = boto3.client('s3', 
                            )
get_last_modified = lambda obj: int(obj['LastModified'].strftime('%s'))
objs = s3_client.list_objects_v2(Bucket='lambdademo-1')['Contents']
last_added = [obj['Key'] for obj in sorted(objs, key=get_last_modified)][-1]

print(last_added)


def lambda_handler(event, context):
   # This address must be verified with Amazon SES.
   SENDER = "yogenders109@gmail.com"
 
   # If your account is still in the sandbox, this address must be verified.
   RECIPIENT = "yogenders109@gmail.com"
 
   # Specify a configuration set. If you do not want to use a configuration
   # set, comment the following variable, and the 
   # ConfigurationSetName=CONFIGURATION_SET argument below.
   # CONFIGURATION_SET = "ConfigSet"
 
   # The AWS Region you're using for Amazon SES.
   AWS_REGION = "us-east-1"
 
   # The subject line for the email.
   SUBJECT = "New object added or Existing Object update"
 
   # The email body for recipients with non-HTML email clients.
   BODY_TEXT = "..."
             
   # The HTML body of the email.
   BODY_HTML = """<html> <head></head> <body> <h1>S3 Bucket updated or New file Added (SDK for Python)</h1> <p> Last Modified file {}</p> </body> </html>""".format(last_added)            
 
   # The character encoding for the email.
   CHARSET = "UTF-8"
 
   # Create a new SES resource and specify a region.
   client = boto3.client('ses',region_name=AWS_REGION)
 
   # Try to send the email.
   try:
       #Provide the contents of the email.
       response = client.send_email(
           Destination={
               'ToAddresses': [
                   RECIPIENT,
               ],
           },
           Message={
               'Body': {
                   'Html': {
                       'Charset': CHARSET,
                       'Data': BODY_HTML,
                   },
                   'Text': {
                       'Charset': CHARSET,
                       'Data': BODY_TEXT,
                   },
               },
               'Subject': {
                   'Charset': CHARSET,
                   'Data': SUBJECT,
               },
           },
           Source=SENDER,
           # If you are not using a configuration set, comment or delete the
           # following line
           # ConfigurationSetName=CONFIGURATION_SET,
     )
   # Display an error if something goes wrong. 
   except ClientError as e:
       return(e.response['Error']['Message'])
   else:
       return("Email sent! Message ID:" + response['MessageId'] )
       

